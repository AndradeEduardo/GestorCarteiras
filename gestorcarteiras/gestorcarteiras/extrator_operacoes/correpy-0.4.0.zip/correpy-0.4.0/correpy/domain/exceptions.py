class InvalidBrokerageNoteFeeTypeException(Exception):
    pass
