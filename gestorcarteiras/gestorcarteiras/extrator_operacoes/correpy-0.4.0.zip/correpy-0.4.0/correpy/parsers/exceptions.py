class InvalidPasswordException(Exception):
    pass


class ProblemParsingBrokerageNoteException(Exception):
    pass
